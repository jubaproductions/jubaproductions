package dragonRun;

import processing.core.PApplet;
import processing.core.PImage;

public class Sketch extends PApplet {
  PImage dragon;
  PImage obstacle;
  PImage obstacleF;
  PImage backgroundFarB;
  PImage backgroundForB;
  boolean down = false;
  boolean up = true;
  boolean notInAir = true;
  boolean alive = true;
  boolean changeUp = true;
  boolean changeDown = false;
  int startTime;
  int timer;
  int highScore = 20;
  int R_B = 180;
  int bgfX = 0;
  int life = 2;
  int bgfY = -30;
  int bgfoX = 0;
  int rgbChange = 1;

  enum GameState {
    GAMEOVER, RUNNING
  }

  int livesD = 2;
  int lives;
  static GameState currentState;
  int bgfoY = -30;
  int score;
  int dragonX = 100;
  int dragonY = 440;
  public int obsticalX = width;
  int obsticalY = 450;
  float speed = 1;
  float speed1 = 4;
  float obsticalspeed = 8;
  int jumpHeight;

  public void settings() {
    size(500, 500);
  }

  public void setup() {
    currentState = GameState.RUNNING;
    dragon = loadImage("Images/Dina.gif");
    backgroundFarB = loadImage("Images/FarB1.png");
    backgroundForB = loadImage("Images/ForB1.png");
    obstacleF = loadImage("Images/Hidren2.png");
    obstacleF.resize(80, 80);
    startTime = millis();
    lives = livesD;
  }

  public void draw() {
    switch (currentState) {

      case RUNNING:
        drawbackground();
        drawFarB();
        drawForB();
        drawRoad();
        drawDragon();
        createObsticals();
        timer = (millis() - startTime) / 1000;
        drawScore();
        drawLives();
        break;

      case GAMEOVER:
        drawEnd();
        break;

    }
  }

  public void drawLives() {
    fill(255, 255, 255);
    textAlign(CENTER);
    text("Lives: " + lives, width - 200, 30);
  }

  public void drawEnd() {
    if (rgbChange >= 180) {
      changeUp = false;
      changeDown = true;
    }
    if (rgbChange <= 10) {
      changeDown = false;
      changeUp = true;
    }
    if (changeUp && !changeDown) {
      rgbChange += 1;
    }
    if (changeDown && !changeUp) {
      rgbChange -= 1;
    }
    fill(0, 0, 0);
    noStroke();
    rect(width / 2 - 135, height / 2 - 90, 270, 180);
    fill(rgbChange, 0, rgbChange);
    noStroke();
    rect(width / 2 - 125, height / 2 - 80, 250, 160);
    fill(255, 100, 100);
    textAlign(CENTER);
    text("Game Over!", width / 2, height / 2 - 50);
    text("Your Score " + score, width / 2, height / 2 - 30);
    text("High Score " + highScore, width / 2, height / 2 - 10);
  }

  public int getrand(int max) {
    System.out.println("hi");
    return 0;
  }

  public void drawScore() {
    fill(255, 255, 255);
    textAlign(CENTER);
    text("Score: " + timer, width - 70, 30);
  }

  public void createObsticals() {
    imageMode(CENTER);
    image(obstacleF, obsticalX, obsticalY);
    obsticalX -= obsticalspeed;
    if (obsticalX < -10) {
      obsticalX = width + 5;
    }
    if ((abs(dragonX - obsticalX) < 40) && abs(dragonY - obsticalY) < 80) {
      if (lives <= 0) {
        score = timer;
        if (score > highScore) {
          highScore = score;
        }
        currentState = GameState.GAMEOVER;
      }
      lives -= 1;
    }
  }

  public void mousePressed() {
    if (currentState == GameState.RUNNING) {
      if (dragonY >= 440) {
        jumpHeight = -20;
        dragonY += jumpHeight;
      }
    }
    if (currentState == GameState.GAMEOVER) {
      startTime = millis();
      currentState = GameState.RUNNING;
      obsticalX = width + 5;
      lives = livesD;
    }
  }

  public void drawbackground() {
    background(R_B, 0, R_B);
    if (R_B > 180) {
      down = true;
      up = false;
    }
    if (R_B < 80) {
      up = true;
      down = false;
    }
    if (up) {
      R_B += 1;
    }
    if (down) {
      R_B -= 1;
    }
  }

  public void drawFarB() {
    imageMode(CORNER);
    image(backgroundFarB, bgfX, bgfY);
    image(backgroundFarB, bgfX + backgroundFarB.width, bgfY);
    bgfX -= speed;
    if (bgfX <= (this.width * -1)) {
      bgfX = 0;
    }
  }

  public void drawForB() {
    imageMode(CORNER);
    image(backgroundForB, bgfoX, bgfoY);
    image(backgroundForB, bgfoX + backgroundFarB.width, bgfoY);
    bgfoX -= speed1;
    if (bgfoX <= (this.width * -1)) {
      bgfoX = 0;
    }
  }

  public void drawRoad() {
    imageMode(CORNER);
    fill(100, 90, 100);
    rect(0, 470, 500, 30);
  }

  public void drawDragon() {
    imageMode(CENTER);
    if (dragonY <= 440) {
      jumpHeight += 1;
      dragonY += jumpHeight;
    }
    image(dragon, dragonX, dragonY);
  }
}